package com.modelos.tempo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        EditText input1 = findViewById(R.id.input1);
        EditText input2 = findViewById(R.id.input2);
        TextView result = findViewById(R.id.result);
        findViewById(R.id.calculate).setOnClickListener(view -> {
            try {
                double value1 = Double.parseDouble(input1.getText().toString().trim().replace(',', '.'));
                double value2 = Double.parseDouble(input2.getText().toString().trim().replace(',', '.'));
                String formatted = new java.text.DecimalFormat("0.##").format(((value1 * 60) + value2));
                result.setText("Total em minutos: " + formatted);
            } catch (NumberFormatException error) {
                result.setText("Preencha todos os campos com números válidos.");
            }
        });
    }
}
