package com.modelos.texto;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        EditText input1 = findViewById(R.id.input1);
        TextView result = findViewById(R.id.result);
        findViewById(R.id.calculate).setOnClickListener(view -> {
            try {

                String formatted = new java.text.DecimalFormat("0.##").format(input1.getText().length());
                result.setText("Caracteres: " + formatted);
            } catch (NumberFormatException error) {
                result.setText("Preencha todos os campos com números válidos.");
            }
        });
    }
}
