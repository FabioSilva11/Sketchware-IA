package com.modelos.farol;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff496926;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Farol das Palavras", 26));
        page.addView(label("Use as letras da rodada. A letra O é obrigatória.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final String letters="ALROSTM";
    final Set<String> dictionary=new HashSet<>(Arrays.asList(
            "AMOR","ASTRO","ATALO","ATO","LAMAO","LOTO","MALTO","MOLAS","MOLA","MORAL",
            "MORRO","MORTAL","MOTOR","ORLA","ORLO","OSSO","ROLA","ROLO","ROSA","ROSTO","ROTA",
            "SALMO","SALTO","SOL","SOLAR","SOLO","SOMA","SORTA","TALOS","TALO","TOMA","TOMAR","TORO","TOSAR","TRATO"));
    final Set<String> found=new LinkedHashSet<>();
    String word="";
    TextView feedback, list;
    void start() {
        feedback=label("",15);
        list=label("",15);
        LinearLayout keys=null;
        for(int i=0;i<letters.length();i++) {
            if(i%4==0) keys=row();
            final char letter=letters.charAt(i);
            TextView key=control(keys,String.valueOf(letter),52,()->{
                if(word.length()<12) word+=letter;
                feedback.setText("");
                render();
            });
            if(letter!='O') paint(key,0xffe1f2c6,false);
        }
        LinearLayout actions=row();
        control(actions,"Validar",48,this::check);
        control(actions,"Apagar",48,()->{if(!word.isEmpty()) word=word.substring(0,word.length()-1); render();});
        page.addView(feedback);
        page.addView(list);
        render();
    }
    void check() {
        if(!word.contains("O")) feedback.setText("Use a letra O.");
        else if(!dictionary.contains(word)) feedback.setText("A palavra não está no dicionário desta rodada.");
        else if(!found.add(word)) feedback.setText("Você já encontrou esta palavra.");
        else {feedback.setText("Boa! Palavra encontrada."); word="";}
        render();
    }
    void render() {
        int score=0;
        for(String hit:found) score+=hit.length()*10;
        status.setText(found.size()+" / "+dictionary.size()+" palavras · "+score+" pontos\n"+(word.isEmpty()?"Monte sua palavra":word));
        list.setText(String.join(" · ",found));
    }
}
