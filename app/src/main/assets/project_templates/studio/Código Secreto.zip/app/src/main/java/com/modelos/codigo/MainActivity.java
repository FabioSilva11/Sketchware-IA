package com.modelos.codigo;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff824170;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Código Secreto", 26));
        page.addView(label("Descubra as quatro cores em até oito tentativas.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final String[] colors={"Rosa","Azul","Verde","Ouro"};
    final int[] palette={0xffa84262,0xff315daa,0xff25805a,0xff9b5a15};
    final int[] code=new int[4];
    final ArrayList<Integer> guess=new ArrayList<>();
    TextView history;
    int attempts;
    boolean finished;
    void start() {
        history=label("",14);
        page.addView(history);
        LinearLayout options=row();
        for(int i=0;i<4;i++) { final int color=i;
            paint(control(options,colors[i],48,()->{
                if(!finished && guess.size()<4) {guess.add(color); render();}
            }),palette[i],true);
        }
        LinearLayout actions=row();
        control(actions,"Confirmar",48,this::check);
        control(actions,"Limpar",48,()->{guess.clear(); render();});
        control(row(),"Nova partida",48,this::reset);
        reset();
    }
    void reset() {
        for(int i=0;i<4;i++) code[i]=random.nextInt(colors.length);
        attempts=0;
        finished=false;
        guess.clear();
        history.setText("");
        render();
    }
    void check() {
        if(finished || guess.size()!=4) return;
        int exact=0, misplaced=0;
        int[] secretCounts=new int[4], guessCounts=new int[4];
        for(int i=0;i<4;i++) {
            if(code[i]==guess.get(i)) exact++;
            else {secretCounts[code[i]]++; guessCounts[guess.get(i)]++;}
        }
        for(int i=0;i<4;i++) misplaced+=Math.min(secretCounts[i],guessCounts[i]);
        attempts++;
        history.append(attempts+". "+names(guess)+"\n"+exact+" certas · "+misplaced+" fora de posição\n\n");
        guess.clear();
        finished=exact==4 || attempts==8;
        if(exact==4) history.append("Você descobriu o código!");
        else if(finished) {
            ArrayList<Integer> answer=new ArrayList<>();
            for(int color:code) answer.add(color);
            history.append("Código: "+names(answer));
        }
        render();
    }
    String names(List<Integer> indexes) {
        ArrayList<String> names=new ArrayList<>();
        for(int color:indexes) names.add(colors[color]);
        return String.join(" · ",names);
    }
    void render() {
        status.setText(finished?"Partida encerrada":"Tentativa "+(attempts+1)+" / 8\n"+names(guess));
    }
}
