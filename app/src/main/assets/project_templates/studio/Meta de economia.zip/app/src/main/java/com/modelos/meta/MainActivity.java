package com.modelos.meta;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        EditText input1 = findViewById(R.id.input1);
        EditText input2 = findViewById(R.id.input2);
        EditText input3 = findViewById(R.id.input3);
        TextView result = findViewById(R.id.result);
        findViewById(R.id.calculate).setOnClickListener(view -> {
            try {
                double value1 = Double.parseDouble(input1.getText().toString().trim().replace(',', '.'));
                double value2 = Double.parseDouble(input2.getText().toString().trim().replace(',', '.'));
                double value3 = Double.parseDouble(input3.getText().toString().trim().replace(',', '.'));
                if (value3 <= 0) {
                    result.setText("Informe um divisor maior que zero.");
                    return;
                }
                String formatted = new java.text.DecimalFormat("0.##").format(((value1 - value2) / value3));
                result.setText("Por mês: R$ " + formatted);
            } catch (NumberFormatException error) {
                result.setText("Preencha todos os campos com números válidos.");
            }
        });
    }
}
