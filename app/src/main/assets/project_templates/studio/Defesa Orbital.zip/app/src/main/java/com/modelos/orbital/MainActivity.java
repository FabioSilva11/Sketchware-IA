package com.modelos.orbital;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff365f74;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Defesa Orbital", 26));
        page.addView(label("Monte sua defesa antes de iniciar a onda.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final TextView[] cells=new TextView[36];
    final int[] towers=new int[36];
    int credits=150, lives=10, wave=0, type=1;
    boolean running;
    String note="";
    void start() {
        for(int y=0;y<6;y++) {
            LinearLayout line=row();
            for(int x=0;x<6;x++) {final int slot=y*6+x;
                cells[slot]=control(line,"",48,()->build(slot));
            }
        }
        LinearLayout shop=row();
        control(shop,"Laser · 50",48,()->{type=1; render();});
        control(shop,"Pulso · 75",48,()->{type=2; render();});
        control(row(),"Iniciar onda",48,this::advance);
        control(row(),"Reiniciar missão",48,()->{
            Arrays.fill(towers,0); credits=150; lives=10; wave=0; note=""; render();
        });
        render();
    }
    void build(int slot) {
        if(slot/6==2 || towers[slot]!=0 || lives==0 || wave==8) return;
        int cost=type==1?50:75;
        if(credits<cost) note="Créditos insuficientes.";
        else {credits-=cost; towers[slot]=type; note="Torre posicionada.";}
        render();
    }
    void advance() {
        if(lives==0 || wave==8) return;
        wave++;
        int enemyCount=2+wave, eliminated=0;
        for(int lane=0;lane<6;lane++) {
            int damage=0;
            for(int i=0;i<towers.length;i++) {
                int distance=Math.abs(i/6-2)+Math.abs(i%6-lane);
                if(towers[i]==1 && distance<=2) damage+=2;
                if(towers[i]==2 && distance<=3) damage+=3;
            }
            eliminated+=Math.min(2,damage/(wave+1));
        }
        int stopped=Math.min(enemyCount,eliminated);
        credits+=35+stopped*15;
        lives=Math.max(0,lives-(enemyCount-stopped));
        note=lives==0?"A base caiu. Reinicie a missão.":wave==8?"Defesa concluída!":stopped+" inimigos detidos.";
        render();
    }
    void render() {
        status.setText("Onda "+wave+"/8 · "+credits+" créditos · Base "+lives+"/10\n"
                +(type==1?"Laser":"Pulso")+" selecionado · "+note);
        for(int i=0;i<36;i++) {
            int tower=towers[i];
            cells[i].setText(tower==1?"L":tower==2?"P":i/6==2?"═":"");
            paint(cells[i],tower!=0?accent:i/6==2?0xffbee5f6:0xffe9e5ed,tower!=0);
        }
    }
}
