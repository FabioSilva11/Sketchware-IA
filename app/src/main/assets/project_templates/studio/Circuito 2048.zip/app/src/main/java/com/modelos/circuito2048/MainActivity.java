package com.modelos.circuito2048;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity extends Activity {
    private final int[] board = new int[16];
    private final TextView[] tiles = new TextView[16];
    private final Random random = new Random();
    private int[] undo;
    private int score, previousScore, best;
    private TextView stats, message;
    private Button undoButton;
    private float downX, downY;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        best = getPreferences(0).getInt("best", 0);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(16));
        page.setBackgroundColor(0xFFFFFBF4);
        setContentView(page);
        page.addView(label("Circuito 2048", 28));
        page.addView(label("Combine peças iguais e alcance 2048.", 15));
        stats = label("", 20);
        stats.setPadding(0, dp(18), 0, dp(12));
        page.addView(stats);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        page.addView(grid);
        for (int row = 0; row < 4; row++) {
            LinearLayout line = new LinearLayout(this);
            grid.addView(line, new LinearLayout.LayoutParams(-1, dp(65)));
            for (int col = 0; col < 4; col++) {
                TextView tile = label("", 22);
                tile.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(0, -1, 1);
                size.setMargins(dp(3), dp(3), dp(3), dp(3));
                line.addView(tile, size);
                tiles[row * 4 + col] = tile;
            }
        }
        grid.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                downX = event.getX();
                downY = event.getY();
                return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                float x = event.getX() - downX;
                float y = event.getY() - downY;
                if (Math.max(Math.abs(x), Math.abs(y)) >= dp(20)) {
                    move(Math.abs(x) > Math.abs(y), Math.abs(x) > Math.abs(y) ? x > 0 : y > 0);
                }
                return true;
            }
            return true;
        });
        message = label("", 14);
        message.setPadding(0, dp(12), 0, dp(8));
        page.addView(message);
        LinearLayout actions = new LinearLayout(this);
        page.addView(actions);
        undoButton = new Button(this);
        undoButton.setText("Desfazer");
        undoButton.setOnClickListener(view -> {
            if (undo == null) return;
            System.arraycopy(undo, 0, board, 0, board.length);
            score = previousScore;
            undo = null;
            render();
        });
        actions.addView(undoButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button restart = new Button(this);
        restart.setText("Nova partida");
        restart.setOnClickListener(view -> reset());
        actions.addView(restart, new LinearLayout.LayoutParams(0, dp(48), 1));
        if (state != null && state.getIntArray("board") != null) {
            System.arraycopy(state.getIntArray("board"), 0, board, 0, board.length);
            score = state.getInt("score");
            previousScore = state.getInt("previousScore");
            undo = state.getIntArray("undo");
            render();
        } else reset();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putIntArray("board", board);
        state.putInt("score", score);
        state.putInt("previousScore", previousScore);
        state.putIntArray("undo", undo);
    }

    private void reset() {
        Arrays.fill(board, 0);
        score = 0;
        undo = null;
        spawn();
        spawn();
        render();
    }

    private void spawn() {
        ArrayList<Integer> empty = new ArrayList<>();
        for (int i = 0; i < board.length; i++) if (board[i] == 0) empty.add(i);
        if (!empty.isEmpty()) board[empty.get(random.nextInt(empty.size()))] = random.nextInt(10) == 0 ? 4 : 2;
    }

    private int index(int line, int offset, boolean horizontal, boolean reverse) {
        int position = reverse ? 3 - offset : offset;
        return horizontal ? line * 4 + position : position * 4 + line;
    }

    private void move(boolean horizontal, boolean reverse) {
        int[] before = board.clone();
        int initialScore = score;
        for (int line = 0; line < 4; line++) {
            int[] values = new int[4];
            int size = 0;
            for (int offset = 0; offset < 4; offset++) {
                int value = board[index(line, offset, horizontal, reverse)];
                if (value != 0) values[size++] = value;
                board[index(line, offset, horizontal, reverse)] = 0;
            }
            int target = 0;
            for (int source = 0; source < size; source++) {
                int value = values[source];
                if (source + 1 < size && value == values[source + 1]) {
                    value *= 2;
                    score += value;
                    source++;
                }
                board[index(line, target++, horizontal, reverse)] = value;
            }
        }
        if (Arrays.equals(before, board)) return;
        undo = before;
        previousScore = initialScore;
        if (score > best) {
            best = score;
            getPreferences(0).edit().putInt("best", best).apply();
        }
        spawn();
        render();
    }

    private boolean hasMove() {
        for (int i = 0; i < board.length; i++) {
            if (board[i] == 0 || i % 4 < 3 && board[i] == board[i + 1]
                    || i < 12 && board[i] == board[i + 4]) return true;
        }
        return false;
    }

    private void render() {
        boolean reachedGoal = false;
        for (int i = 0; i < board.length; i++) {
            int value = board[i];
            reachedGoal |= value >= 2048;
            tiles[i].setText(value == 0 ? "" : String.valueOf(value));
            tiles[i].setContentDescription(value == 0 ? "Vazio" : String.valueOf(value));
            GradientDrawable shape = new GradientDrawable();
            shape.setCornerRadius(dp(10));
            shape.setColor(value == 0 ? 0xFFEDE3D5 : value >= 32 ? 0xFF76572A : 0xFFFAE2B9);
            tiles[i].setTextColor(value >= 32 ? 0xFFFFFFFF : 0xFF332614);
            tiles[i].setBackground(shape);
        }
        stats.setText("Pontos " + score + "   •   Recorde " + best);
        message.setText(!hasMove() ? "Fim da partida. Desfaça ou reinicie."
                : reachedGoal ? "Você alcançou 2048! Continue para bater seu recorde."
                : "Deslize o tabuleiro para mover todas as peças.");
        undoButton.setEnabled(undo != null);
    }

    private TextView label(String text, int size) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(0xFF332614);
        if (size >= 20) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
