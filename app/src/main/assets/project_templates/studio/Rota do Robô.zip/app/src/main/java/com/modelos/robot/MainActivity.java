package com.modelos.robot;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff365997;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Rota do Robô", 26));
        page.addView(label("Monte uma sequência e alcance a estação.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final String[][] levels = {
        {"......",".##.G.","......","......","..#...","S....."},
        {"S..#..",".#.#G.","...#..",".#....",".###..","......"},
        {"S..#G.","##.#..","...#..",".###..","......","......"}
    };
    final TextView[] cells = new TextView[36];
    final ArrayList<Integer> queue = new ArrayList<>();
    int level, position;
    String feedback = "";
    void start() {
        for (int y=0;y<6;y++) {
            LinearLayout row=row();
            for(int x=0;x<6;x++) cells[y*6+x]=control(row,"",48,()->{});
        }
        LinearLayout commands=row();
        String[] arrows={"↑","→","↓","←"};
        for(int i=0;i<4;i++) { final int step=i;
            control(commands,arrows[i],48,()->{if(queue.size()<12) queue.add(step); feedback=""; render();});
        }
        LinearLayout actions=row();
        control(actions,"Executar",48,this::execute);
        control(actions,"Limpar",48,()->{queue.clear(); feedback=""; render();});
        reset();
    }
    char cell(int index) { return levels[level][index/6].charAt(index%6); }
    void reset() {
        queue.clear();
        for(int i=0;i<36;i++) if(cell(i)=='S') position=i;
        render();
    }
    void execute() {
        if(queue.isEmpty()) return;
        int[] steps={-6,1,6,-1};
        int next=position;
        for(int command:queue) {
            int candidate=next+steps[command];
            if(candidate<0 || candidate>=36 || command==1 && next%6==5
                    || command==3 && next%6==0 || cell(candidate)=='#') {
                feedback="Bloqueado. Ajuste a sequência.";
                render(); return;
            }
            next=candidate;
            if(cell(next)=='G') {
                feedback=level==levels.length-1 ? "Campanha concluída! Voltando à primeira fase." : "Fase concluída!";
                level=(level+1)%levels.length; reset(); return;
            }
        }
        position=next;
        queue.clear();
        feedback="Sequência executada.";
        render();
    }
    void render() {
        StringBuilder commands=new StringBuilder();
        String[] arrows={"↑","→","↓","←"};
        for(int command:queue) commands.append(arrows[command]).append(' ');
        status.setText("Fase "+(level+1)+" de "+levels.length+" · "+queue.size()+"/12\n"+commands+"\n"+feedback);
        for(int i=0;i<36;i++) {
            char cell=cell(i);
            cells[i].setText(i==position?"◈":cell=='G'?"◎":cell=='#'?"■":"");
            paint(cells[i],i==position?accent:cell=='#'?0xff635c6b:0xffdbe6ff,i==position||cell=='#');
        }
    }
}
