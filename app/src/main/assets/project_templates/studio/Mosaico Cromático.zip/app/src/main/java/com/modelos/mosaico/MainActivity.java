package com.modelos.mosaico;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff95463b;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Mosaico Cromático", 26));
        page.addView(label("Faça trincas de diamantes antes que acabem os movimentos.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final String[] symbols={"◆","●","▲","✦","■"};
    final int[] colors={0xfff8c1bc,0xffc9deff,0xffd5eec5,0xffe8d5ff,0xffffe9ac};
    final int[] board=new int[36];
    final TextView[] cells=new TextView[36];
    int selected=-1, moves, collected;
    void start() {
        for(int y=0;y<6;y++) {
            LinearLayout line=row();
            for(int x=0;x<6;x++) {final int slot=y*6+x;
                cells[slot]=control(line,"",48,()->select(slot));
            }
        }
        control(row(),"Nova partida",48,this::reset);
        reset();
    }
    void reset() {
        moves=20; collected=0; selected=-1;
        shuffle();
        render();
    }
    void shuffle() {
        do {
            for(int i=0;i<36;i++) {
                int tile;
                do tile=random.nextInt(5);
                while((i%6>=2 && tile==board[i-1] && tile==board[i-2])
                        || (i>=12 && tile==board[i-6] && tile==board[i-12]));
                board[i]=tile;
            }
        } while(!hasSwap());
    }
    boolean hasSwap() {
        for(int i=0;i<36;i++) {
            if(i%6<5 && testsSwap(i,i+1) || i<30 && testsSwap(i,i+6)) return true;
        }
        return false;
    }
    boolean testsSwap(int first,int second) {
        swap(first,second);
        boolean match=matches().length!=0;
        swap(first,second);
        return match;
    }
    void swap(int first,int second) {
        int value=board[first]; board[first]=board[second]; board[second]=value;
    }
    void select(int slot) {
        if(moves==0 || collected>=12) return;
        if(slot==selected) {selected=-1; render(); return;}
        if(selected<0 || Math.abs(slot/6-selected/6)+Math.abs(slot%6-selected%6)!=1) {
            selected=slot; render(); return;
        }
        int first=selected; selected=-1;
        if(testsSwap(first,slot)) {
            swap(first,slot); moves--;
            int[] hits;
            while((hits=matches()).length>0) {
                for(int hit:hits) {if(board[hit]==0) collected++; board[hit]=-1;}
                for(int col=0;col<6;col++) {
                    int bottom=5;
                    for(int y=5;y>=0;y--) if(board[y*6+col]>=0) board[bottom--*6+col]=board[y*6+col];
                    while(bottom>=0) board[bottom--*6+col]=random.nextInt(5);
                }
            }
            if(!hasSwap()) shuffle();
        }
        render();
    }
    int[] matches() {
        java.util.BitSet hits=new java.util.BitSet(36);
        for(int i=0;i<36;i++) {
            if(i%6<4 && board[i]==board[i+1] && board[i]==board[i+2]) {hits.set(i);hits.set(i+1);hits.set(i+2);}
            if(i<24 && board[i]==board[i+6] && board[i]==board[i+12]) {hits.set(i);hits.set(i+6);hits.set(i+12);}
        }
        return hits.stream().toArray();
    }
    void render() {
        status.setText(moves+" movimentos · "+collected+" / 12 ◆\n"
                +(collected>=12?"Meta alcançada!":moves==0?"Fim da partida.":"Toque em duas peças vizinhas."));
        for(int i=0;i<36;i++) {
            cells[i].setText(symbols[board[i]]);
            paint(cells[i],i==selected?accent:colors[board[i]],i==selected);
        }
    }
}
