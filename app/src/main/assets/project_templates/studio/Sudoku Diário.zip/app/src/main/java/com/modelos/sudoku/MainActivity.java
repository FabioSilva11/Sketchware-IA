package com.modelos.sudoku;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
    LinearLayout page;
    TextView status;
    Random random = new Random();
    int accent = 0xff5544a3;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(16),dp(16),dp(24));
        page.setBackgroundColor(0xfffffbfe);
        scroll.addView(page);
        setContentView(scroll);
        page.addView(label("Sudoku Diário", 26));
        page.addView(label("Complete as linhas, colunas e regiões.", 14));
        status = label("", 16);
        status.setPadding(0,dp(14),0,dp(12));
        page.addView(status);
        start();
    }
    int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    TextView label(String value, int size) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(0xff1d1b20);
        text.setTextSize(size);
        return text;
    }
    LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        page.addView(row);
        return row;
    }
    TextView control(LinearLayout row, String title, int height, Runnable action) {
        TextView button = label(title, 16);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,dp(height),1);
        params.setMargins(dp(2),dp(2),dp(2),dp(2));
        row.addView(button, params);
        paint(button, accent, true);
        button.setOnClickListener(view -> action.run());
        return button;
    }
    void paint(TextView view, int color, boolean lightText) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        view.setBackground(shape);
        view.setTextColor(lightText ? 0xffffffff : 0xff1d1b20);
    }

    final String solution="534678912672195348198342567859761423426853791713924856961537284287419635345286179";
    final int[] board=new int[81], notes=new int[81];
    final boolean[] fixed=new boolean[81];
    final TextView[] views=new TextView[81];
    int selected=-1, hints=3;
    boolean writingNotes;
    long started;
    void start() {
        long day=System.currentTimeMillis()/86400000L;
        int shift=(int)(day%9);
        for(int i=0;i<81;i++) {
            fixed[i]=(i*17+day)%11<6;
            board[i]=fixed[i]?digit(i,shift):0;
            if(i%9==0) {
                LinearLayout line=row();
                for(int j=i;j<i+9;j++) {final int cell=j;
                    views[j]=control(line,"",38,()->{selected=cell; render();});
                }
            }
        }
        for(int i=0;i<2;i++) {
            LinearLayout keys=row();
            for(int j=1+i*5;j<=Math.min(9,5+i*5);j++) {final int value=j;
                control(keys,String.valueOf(j),48,()->enter(value));
            }
            if(i==1) control(keys,"Apagar",48,()->enter(0));
        }
        LinearLayout actions=row();
        control(actions,"Anotações",48,()->{writingNotes=!writingNotes; render();});
        control(actions,"Dica",48,()->{
            if(selected>=0 && !fixed[selected] && hints>0 && board[selected]!=digit(selected,shift)) {
                hints--; board[selected]=digit(selected,shift); notes[selected]=0; render();
            }
        });
        started=android.os.SystemClock.elapsedRealtime();
        status.postDelayed(new Runnable() {
            @Override public void run() { if(!isFinishing() && !isDestroyed()) {render(); status.postDelayed(this,1000);} }
        },1000);
        render();
    }
    int digit(int i,int shift) {return 1+(solution.charAt(i)-'1'+shift)%9;}
    void enter(int value) {
        if(selected<0 || fixed[selected]) return;
        if(writingNotes && value>0 && board[selected]==0) notes[selected]^=1<<value;
        else {board[selected]=value; notes[selected]=0;}
        render();
    }
    boolean conflict(int i) {
        for(int j=0;j<81;j++) {
            if(i==j || board[i]!=board[j]) continue;
            if(i/9==j/9 || i%9==j%9 || (i/27==j/27 && i%9/3==j%9/3)) return true;
        }
        return false;
    }
    void render() {
        boolean complete=true;
        for(int i=0;i<81;i++) {
            boolean error=board[i]!=0 && conflict(i);
            complete &= board[i]!=0 && !error;
            StringBuilder note=new StringBuilder();
            for(int n=1;n<=9;n++) if((notes[i]&(1<<n))!=0) note.append(n);
            views[i].setTextSize(board[i]==0?9:15);
            views[i].setText(board[i]==0?note.toString():String.valueOf(board[i]));
            int section=(i/27+i%9/3)%2;
            paint(views[i],error?0xffffdada:i==selected?0xffdcd0ff:section==0?0xfff0ebfb:0xffe2daef,false);
        }
        long seconds=(android.os.SystemClock.elapsedRealtime()-started)/1000;
        status.setText(complete?"Grade concluída!":String.format(Locale.ROOT,"%02d:%02d · %d dicas · %s",seconds/60,seconds%60,hints,writingNotes?"Anotações":"Números"));
    }
}
